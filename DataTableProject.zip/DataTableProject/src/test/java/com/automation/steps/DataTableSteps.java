package com.automation.steps;

import com.automation.pages.Datapage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

public class DataTableSteps {
    Datapage datapage=new Datapage();
    @When("user opens the data website")
    public void user_opens_the_data_website() {
        datapage.openWebsite();
    }

    @Then("verify the data is present in the data table")
    public void verify_the_data_is_present_in_the_data_table(List<List<String>> dataTable) {
        datapage.validateData(dataTable);
    }
    }
