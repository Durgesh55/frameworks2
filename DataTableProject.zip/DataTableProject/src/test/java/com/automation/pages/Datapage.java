package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class Datapage {
    WebDriver driver;
    public void openWebsite(){
        driver=new ChromeDriver();
        driver.get("https://datatables.net/");
    }
    public void validateData(List<List<String>> table){
        for (int i=0;i<table.size();i++){
            String xpath="//table[@id='example']/tbody/tr[%s]/td[not(@style='display: none;')]";
            List<WebElement> eachRowData=driver.findElements(By.xpath(String.format(xpath,i+1)));
            for (int j=0;j<eachRowData.size();j++){
                String expData=table.get(i).get(j);
                String actData=eachRowData.get(j).getText();
                System.out.println("Expected  "+ expData);
                System.out.println("Actual    "+ actData);
            }
        }
    }

}
