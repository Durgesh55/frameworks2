package com.automation.steps;

import com.automation.pages.SortPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class SortSteps {
    SortPage sortPage=new SortPage();

    @When("user clicks on low to high sort")
    public void userClicksOnLowToHighSort() {
        sortPage.clickOnLOwToHigh();
    }

    @Then("verify the price is sorted from low to high")
    public void verifyThePriceIsSortedFromLowToHigh() {
        Assert.assertTrue(sortPage.verifySort());
    }

    @When("user clicks on sort")
    public void userClicksOnSort() {
        sortPage.clickSort();
    }
}
