package com.automation.steps;

import com.automation.pages.SearchPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class SearchSteps {

    SearchPage searchPage=new SearchPage();

    @And("user search for {string}")
    public void userSearchFor(String item) {
        searchPage.searchTheItem(item);
    }

    @Then("verify searched product is displayed")
    public void verifySearchedProductIsDisplayed() {
        Assert.assertTrue(searchPage.isProductDisplyed());
    }

    @When("user clicks on first product")
    public void userClicksOnFirstProduct() {
        searchPage.clickOnFirstProduct();
    }

    @And("user clicks on add to cart")
    public void userClicksOnAddToCart() {
        searchPage.clickOnAddToCart();
    }

    @Then("verify product is added to the cart")
    public void verifyProductIsAddedToTheCart() {
        Assert.assertTrue(searchPage.isAddToCartSuccessful());
    }
}
