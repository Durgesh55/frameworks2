package com.automation.steps;

import com.automation.pages.LoginPage;
import com.automation.utils.ConfigReader;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class LoginSteps {
    LoginPage loginPage=new LoginPage();

    @When("user clicks on signIn button")
    public void userClicksOnSignInButton() {
        loginPage.clickLogin();
    }

    @Then("verify user is on login page")
    public void verifyUserIsOnLoginPage() {
        Assert.assertTrue(loginPage.isLoginPageDisplayed());
    }

    @When("user enters the email {string}")
    public void userEntersTheEmail(String email) {
        loginPage.enterEmail(ConfigReader.getConfigValue(email));
    }

    @And("user enters {string}")
    public void userEnters(String password) {
        loginPage.enterPassword(ConfigReader.getConfigValue(password));
    }

    @And("click on login button")
    public void clickOnLoginButton() {
        loginPage.clickOnLoginButton();
    }

    @Then("verify the login is successful")
    public void verifyTheLoginIsSuccessful() {
        Assert.assertTrue(loginPage.isLoginSuccessful());
    }

}
