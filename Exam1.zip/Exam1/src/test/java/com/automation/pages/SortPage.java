package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortPage extends BasePage{
    @FindBy(xpath = "//android.widget.ImageView[@resource-id=\"com.banggood.client:id/ic_sort_price\"]")
    WebElement sortButton;
    List<String> sortPrice=new ArrayList<>();
    List<Double> sp=new ArrayList<>();
    public void clickOnLOwToHigh() {
        List<WebElement> price=driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"]"));
        for(WebElement e:price){
            String s=e.getText();
            String s1=s.substring(1);
            sortPrice.add(s1.replaceAll(",",""));
        }
        for (String f:sortPrice){
            System.out.println(f);
            sp.add(Double.parseDouble(f));
        }
    }

    public boolean verifySort() {
        List<Double> sp2=new ArrayList<>(sp);
        Collections.sort(sp2);
        for (Double d:sp2){
            System.out.println(d);
        }
        return sp.equals(sp2);

    }

    public void clickSort() {
        sortButton.click();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
