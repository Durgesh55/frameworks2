package com.automation.pages;

import com.google.common.collect.ImmutableMap;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchPage extends  BasePage {
    @FindBy(xpath = "//android.widget.EditText[@resource-id=\"com.banggood.client:id/edt_search\"]")
    WebElement searchBar;

    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_automated_keyword\" and @text=\"watches for men\"]")
    WebElement product;

    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_keyword\"]")
    WebElement searchedItem;

    @FindBy(xpath = "(//android.widget.ImageView[@resource-id=\"com.banggood.client:id/iv_product\"])[1]")
    WebElement firstProduct;

    @FindBy(xpath = "//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_slide_cart\"]")
    WebElement addToCartButton;

    @FindBy(xpath = "//android.widget.LinearLayout[@resource-id=\"com.banggood.client:id/ll_buy_operate\"]/android.widget.LinearLayout")
    WebElement addToCartButton2;

    @FindBy(xpath = "//android.widget.TextView[@text=\"1\"]")
    WebElement verifyCart;


    public void searchTheItem(String item) {
        searchBar.sendKeys(item);
        product.click();
    }

    public boolean isProductDisplyed() {
        return isPresent(searchedItem);
    }

    public void clickOnFirstProduct() {
        firstProduct.click();
    }

    public void clickOnAddToCart() {
        addToCartButton.click();
        addToCartButton2.click();

    }

    public boolean isAddToCartSuccessful() {
        return isPresent(verifyCart);
    }
}
