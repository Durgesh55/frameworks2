package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage{

    @FindBy(xpath = "(//android.widget.ImageView[@resource-id=\"com.banggood.client:id/tab_icon\"])[4]")
    WebElement account;
    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_login\"]")
    WebElement login;
    @FindBy(xpath = "//android.widget.EditText[@resource-id=\"com.banggood.client:id/et_email\"]")
    WebElement email;
    @FindBy(xpath = "//android.widget.EditText[@resource-id=\"com.banggood.client:id/et_pwd\"]")
    WebElement password;
    @FindBy(xpath = "//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_sign_in\"]")
    WebElement signInButton;
    @FindBy(xpath = "//android.widget.ImageView[@resource-id=\"com.banggood.client:id/tv_user_vip_level\"]")
    WebElement user;

    public void clickLogin() {
        account.click();
        login.click();
    }

    public boolean isLoginPageDisplayed() {
        return isPresent(email);
    }

    public void enterEmail(String userEmail) {
        email.clear();
        email.sendKeys(userEmail);
    }

    public void enterPassword(String userPassword) {
        password.clear();
        password.sendKeys(userPassword);
    }

    public void clickOnLoginButton() {
        signInButton.click();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean isLoginSuccessful() {
        return isPresent(user);
    }
}
