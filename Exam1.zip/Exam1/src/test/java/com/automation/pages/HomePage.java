package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{

    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_search\"]")
    WebElement searchBar;

    public void clickOnSearchBar(){
        searchBar.click();
    }

    public boolean isHomePageDisplayed() {
        return isPresent(searchBar);
    }
}
