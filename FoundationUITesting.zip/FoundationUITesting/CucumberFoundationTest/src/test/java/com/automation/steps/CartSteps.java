package com.automation.steps;

import com.automation.pages.CartPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class CartSteps {
    CartPage cartPage=new CartPage();

    @Given("user opens the website")
    public void user_opens_the_website() {
        cartPage.openWebsite();
    }

    @When("user clicks on new arrivals")
    public void user_clicks_on_new_arrivals() {
        cartPage.clickOnNeWArrivals();

    }

    @Then("verify that new arrival page is displayed")
    public void verify_that_new_arrival_page_is_displayed() {
        Assert.assertTrue(cartPage.isNewArrivalPageDisplayed());

    }

    @When("user clicks on product")
    public void user_clicks_on_product() {
        cartPage.clickOnProduct();

    }

    @When("user clicks on add to bag")
    public void user_clicks_on_add_to_bag() {
        cartPage.clickOnAddToBag();

    }

    @Then("verify product is successfully added to the cart")
    public void verify_product_is_successfully_added_to_the_cart() {
        Assert.assertTrue(cartPage.isProductAddedToTheBag());
    }

    }
