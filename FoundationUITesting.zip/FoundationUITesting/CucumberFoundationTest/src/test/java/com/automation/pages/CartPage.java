package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage extends BasePage {

    @FindBy(xpath = "//li[1]/h3//a[@class='drop-anchor']")
    WebElement newArrivalButton;

    @FindBy(xpath = "//h3[@class='total-product-name-count']")
    WebElement newArrivalPage;

    @FindBy(xpath = "//*[@id=\"productCard_route_to_pdp0\"]/img[2]")
    WebElement product;

    @FindBy(xpath = "//button[@class='cart_butoon']")
    WebElement addToBagButton;

    @FindBy(xpath = "//h2[@class='product-title']")
    WebElement productTitle;

    @FindBy(xpath = "//*[@id=\"header_cart_listing\"]/ul/li[7]/a/img")
    WebElement bagIcon;

    @FindBy(xpath = "//div[@class='item_name']")
    WebElement productTitleInBag;

    public void openWebsite() {
        driver.get("https://www.ritukumar.com/");
    }

    public void clickOnNeWArrivals() {
        newArrivalButton.click();
    }

    public boolean isNewArrivalPageDisplayed() {
        String message=newArrivalPage.getText();
        System.out.println(message);
        return message.contains("NEW ARRIVALS");
    }
    public void clickOnProduct(){
        product.click();
    }

    public void clickOnAddToBag() {
        addToBagButton.click();
    }
    public boolean isProductAddedToTheBag(){
        String productTitleOnPDPPage=productTitle.getText();
        System.out.println(productTitleOnPDPPage);
        bagIcon.click();
        String productTitleOnCartPage=productTitleInBag.getText();
        System.out.println(productTitleOnCartPage);
        return  productTitleOnPDPPage.equals(productTitleOnCartPage);
    }
}
