package com.automation.test.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductTest extends BaseTest {
    @Test
    public void verifyTheFiltersOfProduct(){
        productPage.openWebsite();
        productPage.clickOnNewArrival();
        Assert.assertTrue(productPage.isNewArrivalPageDisplayed());
        productPage.selectTheOccasionFilter();
        productPage.selectTheColourFilter();
        productPage.selectTheFabricFilter();
        productPage.selectTheProductTypeFilter();
        productPage.selectSizeFilter();
        productPage.clickOnApply();
        Assert.assertTrue(productPage.isFilterApplied());

    }
}
