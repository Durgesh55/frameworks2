package com.automation.test.tests;

import com.automation.test.pages.ProductPage;
import com.automation.test.utils.DriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.IOException;

public class BaseTest {

    ProductPage productPage;

    @BeforeMethod
    public void setUp() throws IOException {
        DriverManager.createDriver();
        productPage=new ProductPage();
    }
    @AfterMethod
    public void clanUp(){
        DriverManager.getDriver().quit();
    }
}

