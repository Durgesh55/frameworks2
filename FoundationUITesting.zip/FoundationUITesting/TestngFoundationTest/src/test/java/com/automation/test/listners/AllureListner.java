package com.automation.test.listners;

import com.automation.test.utils.AllureReportManager;
import io.qameta.allure.testng.AllureTestNg;
import org.testng.ITestResult;

public class AllureListner extends AllureTestNg {
    @Override
    public void onTestFailure(ITestResult result) {
        AllureReportManager.attachScreenShot();
        AllureReportManager.attachLog("Test got failed");
        super.onTestFailure(result);
    }

}
