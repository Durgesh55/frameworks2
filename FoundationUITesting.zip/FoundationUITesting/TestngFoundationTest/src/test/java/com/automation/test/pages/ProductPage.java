package com.automation.test.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import javax.swing.*;

public class ProductPage extends BasePage{
    @FindBy(xpath = "//li[1]/h3//a[@class='drop-anchor']")
    WebElement newArrivalButton;


    @FindBy(xpath = "//h3[@class='total-product-name-count']")
    WebElement newArrivalPage;



    @FindBy(xpath = "//li[1]/div")
    WebElement occasionFilter;

    @FindBy(xpath = "//label[@for='id0']")
    WebElement occasionCheckBox;

    @FindBy(xpath = "//li[2]/div")
    WebElement colourFilter;

    @FindBy(xpath = "//li[2]/div[2]/ul/li[2]/label")
    WebElement colourCheckBox;

    @FindBy(xpath = "//*[@id=\"filter_ul\"]/li[3]/div")
    WebElement fabricFilter;

    @FindBy(xpath = "//li[4]/label")
    WebElement fabricCheckBox;

    @FindBy(xpath = "//*[@id=\"filter_ul\"]/li[4]/div")
    WebElement productTypeFilter;

    @FindBy(xpath = "//ul/li[11]/label")
    WebElement productTypeCheckBox;

    @FindBy(xpath = "//*[@id=\"filter_ul\"]/li[5]/div")
    WebElement sizeFilter;

    @FindBy(xpath = "//li[2]/label")
    WebElement sizeCheckBox;

    @FindBy(xpath = "//button[@class='apply_btn']")
    WebElement applyButton;

    @FindBy(xpath = "//div[@class='appliedFilterDiv']")
    WebElement appliedFilter;


    public void openWebsite() {
        driver.get("https://www.ritukumar.com/");
    }

    public void clickOnNewArrival() {
        newArrivalButton.click();

    }

    public void selectTheOccasionFilter() {
        occasionFilter.click();
        occasionCheckBox.click();
    }

    public void selectTheColourFilter() {
        colourFilter.click();
        colourCheckBox.click();
    }

    public void selectTheFabricFilter() {
        fabricFilter.click();
        fabricCheckBox.click();
    }

    public void selectTheProductTypeFilter() {
        productTypeFilter.click();
        productTypeCheckBox.click();
    }

    public void selectSizeFilter() {
        sizeFilter.click();
        sizeCheckBox.click();
    }

    public void clickOnApply() {
        applyButton.click();
    }

    public boolean isFilterApplied() {
        return appliedFilter.isDisplayed();
    }

    public boolean isNewArrivalPageDisplayed() {
        return newArrivalPage.isDisplayed();
    }
}
