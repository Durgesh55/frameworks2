package com.automation.steps;

import com.automation.pages.CartPage;
import io.cucumber.java.en.And;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartSteps {
    CartPage cartPage=new CartPage();



    @And("user clicks on first product")
    public void userClicksOnFirstProduct() {
        cartPage.clickOnProduct();
    }
}
