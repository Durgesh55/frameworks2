package com.automation.steps;

import com.automation.pages.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class HomeSteps {
    HomePage homePage = new HomePage();

    @Given("user opens application")
    public void user_opens_application() throws InterruptedException {

        homePage.openApplication();
    }

    @When("user prints the username and password displayed on screen")
    public void userPrintsTheUsernameAndPasswordDisplayedOnScreen() {
        homePage.performScrollAndSwipe();
        homePage.printUsernameAndPassword();

    }

    @And("user login using valid credentials")
    public void userLoginUsingValidCredentials() {
        homePage.performScrollAndSwipe();
        homePage.doLogin();
    }

    @And("print product names")
    public void printProductNames() {
        homePage.printProductDetails();
    }

}
