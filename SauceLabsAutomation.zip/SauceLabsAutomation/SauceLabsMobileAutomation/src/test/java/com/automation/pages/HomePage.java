package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HomePage extends BasePage {

    @FindBy(xpath = "//android.widget.TextView[@text='secret_sauce']")
    WebElement password;

    @FindBy(xpath = "//android.widget.TextView[@text='standard_user']")
    WebElement userName;

    @FindBy(xpath = "//android.widget.EditText[@content-desc='test-Username']")
    WebElement userNameField;

    @FindBy(xpath = "//android.widget.EditText[@content-desc='test-Password']")
    WebElement passwordField;

    @FindBy(xpath = "//android.view.ViewGroup[@content-desc='test-LOGIN']")
    WebElement loginButton;

    @FindBy(xpath = "//android.widget.TextView[@text='\uF099']")
    WebElement end;


    public void openApplication() throws InterruptedException {
        //To catch cookies or pop-up if present
    }

    public void performScrollAndSwipe() {

        while (!isPresent(password)) {
            scroll();
        }
    }

    public void printUsernameAndPassword() {
        List<WebElement> list = driver.findElements(By.xpath("//android.widget.TextView[@text='The currently accepted usernames for this application are (tap to autofill):']/following-sibling::android.view.ViewGroup/android.widget.TextView"));
        for (WebElement userNames : list) {
            System.out.println("user name: " + userNames.getText());
        }
        System.out.println("password: " + password.getText());
    }

    public void doLogin() {
        userNameField.sendKeys(userName.getText());
        passwordField.sendKeys(password.getText());
        loginButton.click();

    }

    Set<WebElement> set = new HashSet<>();

    public void printProductDetails() {
        while (!isPresent(end)) {
            List<WebElement> product = driver.findElements(By.xpath("//android.widget.TextView[@content-desc='test-Item title' ]"));
            for (WebElement title : product) {
                System.out.println(title.getText());
            }
            scroll();

        }

    }
}
